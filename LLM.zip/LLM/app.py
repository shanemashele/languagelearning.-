import os
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
from groq import Groq
from gtts import gTTS
import io
import base64
import hashlib

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your_secret_key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

# Define User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)

# Create the database if it doesn't exist
with app.app_context():
    db.create_all()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def text_to_speech(text):
    tts = gTTS(text, lang='en')
    audio_file = io.BytesIO()
    tts.write_to_fp(audio_file)
    audio_file.seek(0)
    return audio_file

def audio_to_base64(audio_file):
    audio_base64 = base64.b64encode(audio_file.read()).decode('utf-8')
    return f"data:audio/mp3;base64,{audio_base64}"

# Initialize the Groq client
groq_client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = hash_password(request.form['password'])
        name = request.form['name']
        email = request.form['email']

        if User.query.filter_by(username=username).first() is None:
            new_user = User(username=username, password=password, name=name, email=email)
            db.session.add(new_user)
            db.session.commit()
            flash('User registered successfully.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Username already exists.', 'error')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = hash_password(request.form['password'])

        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['logged_in'] = True
            session['username'] = username
            session['name'] = user.name
            session['email'] = user.email
            return redirect(url_for('chat'))
        else:
            flash('Invalid username or password.', 'error')
    return render_template('login.html')

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    if 'logged_in' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        question = request.form['question']

        # Validate if the question is related to teaching or translation
        if not is_valid_question(question):
            flash('Only teaching and translation questions are allowed.', 'error')
            return redirect(url_for('chat'))

        # Use Groq client to get the response
        try:
            chat_completion = groq_client.chat.completions.create(
                messages=[
                    {
                        "role": "user",
                        "content": question,
                    }
                ],
                model="llama3-8b-8192",
            )
            response_text = chat_completion.choices[0].message.content
        except Exception as e:
            response_text = f"Error: {str(e)}"

        # Save the chat history
        chat_history = session.get('chat_history', [])
        chat_history.append({"role": "user", "content": question})
        chat_history.append({"role": "assistant", "content": response_text})
        session['chat_history'] = chat_history

        # Convert response to audio
        audio_file = text_to_speech(response_text)
        audio_base64 = audio_to_base64(audio_file)
        return render_template('chat.html', chat_history=chat_history, audio_base64=audio_base64)

    chat_history = session.get('chat_history', [])
    return render_template('chat.html', chat_history=chat_history)

def is_valid_question(question):
    """Check if the question is related to teaching or translation."""
    teaching_keywords = ['teach', 'education', 'learn', 'study']
    translation_keywords = ['translate', 'translation', 'language']

    question_lower = question.lower()
    for keyword in teaching_keywords:
        if keyword in question_lower:
            return True
    for keyword in translation_keywords:
        if keyword in question_lower:
            return True
    return False

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'logged_in' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form.get('password')

        user = User.query.filter_by(username=session['username']).first()
        if user:
            user.name = name
            user.email = email
            if password:
                user.password = hash_password(password)
            db.session.commit()
            session['name'] = name
            session['email'] = email
            flash('Profile updated successfully.', 'success')

    return render_template('profile.html', name=session.get('name'), email=session.get('email'))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
